from fastapi import FastAPI, Request
from pydantic import BaseModel
from typing import Literal
import numpy as np
import joblib
import logging
import json
import time

from utils.model_loader import select_model
from utils.inference import run_inference
from utils.reasoning import generate_reasoning
from utils.preprocessor import transform_raw_to_behavioral

app = FastAPI(title="Dynamic Fraud API")
SCALER = joblib.load("artifacts/models/scaler.pkl")

# SIMULATED DATABASE: In production, this would be Redis or SQL
CUSTOMER_DB = {
    "CUST_001": {"avg_amt": 120.0, "txn_count": 5, "cat_freq": {"grocery": 10}},
    "CUST_002": {"avg_amt": 4500.0, "txn_count": 25, "cat_freq": {"luxury": 5, "travel": 2}},
}

class RawRequest(BaseModel):
    cc_num: str
    amt: float
    category: str
    lat: float
    long: float
    merch_lat: float
    merch_long: float
    unix_time: int
    model_name: Literal["autoencoder", "isolation_forest", "or_ensemble"] = "autoencoder"

@app.post("/predict")
async def predict(request: RawRequest):
    # 1. Dynamic Lookup: Get history based on cc_num
    # If not found, we assume a 'New Customer' profile
    history = CUSTOMER_DB.get(request.cc_num, {"avg_amt": request.amt, "txn_count": 1, "cat_freq": {}})

    # 2. Transform using the specific customer's context
    behavioral = transform_raw_to_behavioral(request.dict(), history)
    behavioral['category'] = request.category # Pass for reasoning

    # 3. Scale and Infer (using only the 4 features)
    features = np.array([[behavioral[f] for f in ["amt_deviation", "txn_count_cust", "cust_category_count", "distance_from_home"]]])
    features_scaled = SCALER.transform(features)

    m_name, _, models = select_model(request.model_name)
    result = run_inference(features_scaled, m_name, models)

    return {
        "cc_num": request.cc_num,
        "fraud_probability": round(result["fraud_probability"], 3),
        "risk_level": "High" if result["fraud_probability"] > 0.7 else "Low",
        "reasoning": generate_reasoning(behavioral),
        "customer_context": {"avg_spending": history['avg_amt']}
    }
