import numpy as np

def calculate_distance(lat1, lon1, lat2, lon2):
    return np.sqrt((lat1 - lat2)**2 + (lon1 - lon2)**2) * 111

def transform_raw_to_behavioral(raw_data, customer_history):
    """
    Transforms raw data using dynamic customer history.
    customer_history: dict with {'avg_amt': float, 'txn_count': int, 'cat_freq': dict}
    """
    # Use the customer's actual average, or the current amount if new customer
    avg_amt = customer_history.get('avg_amt', raw_data['amt'])
    amt_deviation = abs(raw_data['amt'] - avg_amt)

    distance = calculate_distance(raw_data['lat'], raw_data['long'],
                                 raw_data['merch_lat'], raw_data['merch_long'])

    # Return features + context for reasoning
    return {
        "amt_deviation": amt_deviation,
        "txn_count_cust": customer_history.get('txn_count', 1),
        "cust_category_count": customer_history.get('cat_freq', {}).get(raw_data['category'], 0),
        "distance_from_home": distance,
        "avg_amt_context": avg_amt # Pass this along for smart reasoning
    }

