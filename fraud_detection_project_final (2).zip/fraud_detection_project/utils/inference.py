import numpy as np

def sigmoid_mapping(score, threshold, k):
    """
    threshold: The score that gives exactly 0.5 probability.
    k: How fast it jumps from 0 to 1. Smaller = smoother.
    """
    return 1 / (1 + np.exp(-k * (score - threshold)))

def run_inference(X_scaled, model_name, models):
    if model_name == "autoencoder":
        model = models["autoencoder"]
        recon = model.predict(X_scaled, verbose=0)
        mse = np.mean((X_scaled - recon) ** 2)

        # CALIBRATION:
        # If your 'Normal' raw_score is around 2.0, set threshold to 15.0.
        # This means a score of 2.0 will result in a very LOW probability (~0.01).
        # A score of 15.0 will be 0.5 probability.
        # Only scores > 30.0 will hit 0.999.
        prob = sigmoid_mapping(mse, threshold=25.0, k=0.1)
        raw_score = mse

    elif model_name == "isolation_forest":
        model = models["isolation_forest"]
        # IsoForest raw scores are smaller, usually between -0.2 and 0.3
        raw_score = -model.decision_function(X_scaled)[0]
        prob = sigmoid_mapping(raw_score, threshold=0.15, k=10.0)

    elif model_name == "or_ensemble":
        res_iso = run_inference(X_scaled, "isolation_forest", models)
        res_ae = run_inference(X_scaled, "autoencoder", models)
        prob = max(res_iso["fraud_probability"], res_ae["fraud_probability"])
        raw_score = max(res_iso["raw_score"], res_ae["raw_score"])

    return {
        "fraud_probability": float(min(prob, 0.999)),
        "raw_score": float(raw_score)
    }
