def generate_reasoning(features):
    reasons = []

    # DYNAMIC: Flag if the deviation is more than 3x the customer's normal average
    avg = features.get("avg_amt_context", 1)
    if features["amt_deviation"] > (3 * avg):
        reasons.append(f"The amount is significantly higher than the customer's average spending of ${round(avg, 2)}.")

    if features["distance_from_home"] > 100:
        reasons.append("The transaction is occurring unusually far from the customer's registered home location.")

    if features["cust_category_count"] == 0:
        reasons.append(f"This is the first time the customer has shopped in the '{features.get('category', 'current')}' category.")

    if not reasons:
        reasons.append("Transaction patterns are consistent with normal behavior.")

    return reasons
